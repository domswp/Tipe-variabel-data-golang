package main

import (
	"fmt"

	"golang.org/x/text/message"
)

func main() {
	// Running make Var
	var nama string = "Freya"
	var umur int = 33

	// Tidak pake var
	kota := "Surabaya"
	gaji := 3500000.0

	// Menampilkan semua variabel
	fmt.Println("Nama:", nama)
	fmt.Println("Umur:", umur)
	fmt.Println("Kota:", kota)

	// Format angka pakai pemisah ribuan
	p := message.NewPrinter(message.MatchLanguage("id"))
	p.Printf("Gaji: Rp%d\n", int(gaji))
}
