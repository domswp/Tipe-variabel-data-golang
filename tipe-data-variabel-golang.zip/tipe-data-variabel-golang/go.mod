module tipedata

go 1.24.1

require golang.org/x/text v0.24.0 // indirect
